package com.cg.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bookingdetails")
public class Book {
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.AUTO)
private int id;
	@Column(name="customername")
private String customerName;
	@Column(name="hotelid")
private int hotelId;
@Column(name="todate")
private Date toDate;
@Column(name="fromdate")
private Date fromDate;
@Column(name="noofrooms")
private int noOfRooms;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public int getHotelId() {
	return hotelId;
}
public void setHotelId(int hotelId) {
	this.hotelId = hotelId;
}
public Date getToDate() {
	return toDate;
}
public void setToDate(Date toDate) {
	this.toDate = toDate;
}
public Date getFromDate() {
	return fromDate;
}
public void setFromDate(Date fromDate) {
	this.fromDate = fromDate;
}
public int getNoOfRooms() {
	return noOfRooms;
}
public void setNoOfRooms(int noOfRooms) {
	this.noOfRooms = noOfRooms;
}
public Book(int id, String customerName, int hotelId, Date toDate,
		Date fromDate, int noOfRooms) {
	super();
	this.id = id;
	this.customerName = customerName;
	this.hotelId = hotelId;
	this.toDate = toDate;
	this.fromDate = fromDate;
	this.noOfRooms = noOfRooms;
}
public Book() {
	super();
	
}
@Override
public String toString() {
	return "Book [id=" + id + ", customerName=" + customerName + ", hotelId="
			+ hotelId + ", toDate=" + toDate + ", fromDate=" + fromDate
			+ ", noOfRooms=" + noOfRooms + "]";
}

}
