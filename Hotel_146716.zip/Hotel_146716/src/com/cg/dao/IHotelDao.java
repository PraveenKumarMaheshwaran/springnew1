package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.Book;
import com.cg.dto.Hotel;

public interface IHotelDao {
public ArrayList<Hotel> getAllHotels();
public Book addCustomer(Book bk) ;
}
