package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.dto.Book;
import com.cg.dto.Hotel;


@Repository("dao")
@Transactional
public class HotelDaoImpl implements IHotelDao{
	@PersistenceContext
	private EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	@Override
	public ArrayList<Hotel> getAllHotels() {
		//System.out.println("dao");
		String qry="select ht from Hotel ht";
		TypedQuery<Hotel> tq=entityManager.createQuery(qry,Hotel.class);
		ArrayList<Hotel> userL=(ArrayList)tq.getResultList();
		//System.out.println("daolast");
		return userL;
	}

	@Override
	public Book addCustomer(Book bk) {
		System.out.println("in dao.....");
		entityManager.persist(bk);
		return bk;
	}
}
