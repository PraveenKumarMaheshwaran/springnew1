package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.Book;
import com.cg.dto.Hotel;

public interface IHotelService {
	public ArrayList<Hotel> getAllHotels();
	public Book addCustomer(Book bk) ;
}
