package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IHotelDao;
import com.cg.dto.Book;
import com.cg.dto.Hotel;
@Service("service")
public class HotelServiceImpl implements IHotelService{
	@Autowired
	IHotelDao dao;

	public IHotelDao getDao() {
		return dao;
	}

	public void setDao(IHotelDao dao) {
		this.dao = dao;
	}
	@Override
	public ArrayList<Hotel> getAllHotels() {
		System.out.println("service");
		return dao.getAllHotels();
	}

	@Override
	public Book addCustomer(Book bk) {
		System.out.println("In service.........");
		return dao.addCustomer(bk);
	}

}
