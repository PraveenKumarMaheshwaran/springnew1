package com.cg.cntlr;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.Book;
import com.cg.dto.Hotel;

import com.cg.service.IHotelService;


@Controller
public class BookingController {
	
	@Autowired
	IHotelService service;
	ArrayList<String> domainList=null;

	public IHotelService getService() {
		return service;
	}

	public void setService(IHotelService service) {
		this.service = service;
	}

	@RequestMapping(value="/ShowIndexpage",method=RequestMethod.GET)
	public String showIndexPage(Model model)
	{
		System.out.println("controller");
		ArrayList<Hotel> usr=service.getAllHotels();
		model.addAttribute("UserList",usr);
		return "Index";
	}
	@RequestMapping(value="/booking",method=RequestMethod.GET)
	public String bookHotel(Model model,@ModelAttribute(value="store")Book book,@RequestParam(value="id") int id,@RequestParam(value="name") String name,@RequestParam(value="rate") String rate)
	{
		model.addAttribute("store",book);
	model.addAttribute("id",id);
	model.addAttribute("name",name);
	model.addAttribute("rate",rate);
		return "Booking";
	}
	@RequestMapping(value="/booked",method=RequestMethod.GET)
	public String bookedInfo(Model model,@ModelAttribute(value="Book")Book book1,@RequestParam(value="name") String name)
	{
		//,@RequestParam(value="rate") String rate
		System.out.println("In ctrl...");
		//Book book=new Book();
		//,@ModelAttribute(value="Book")Book book,) int rooms
		 Book tr = service.addCustomer(book1);
		//model.addAttribute("Book",book1);
		 System.out.println("1");
	    model.addAttribute("name",name);
	    //model.addAttribute("rate",rate);
	    System.out.println("2");
	    //model.addAttribute("noOfRooms",rooms);
		 System.out.println("lastIn ctrl...");
		 model.addAttribute("bookeddata",tr);
		 
		return "Booked";
	}
}
